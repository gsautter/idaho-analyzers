/*
 * Copyright (c) 2006-2008, IPD Boehm, Universitaet Karlsruhe (TH)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package de.uka.ipd.idaho.plugins.taxonomicNames.itis;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Properties;

import de.uka.ipd.idaho.gamta.Annotation;
import de.uka.ipd.idaho.gamta.MutableAnnotation;
import de.uka.ipd.idaho.gamta.util.AbstractConfigurableAnalyzer;
import de.uka.ipd.idaho.plugins.taxonomicNames.TaxonomicNameConstants;

/**
 * @author sautter
 *
 */
public class HigherHierarchyImporter  extends AbstractConfigurableAnalyzer implements TaxonomicNameConstants {
	
	private ItisHigherHierarchyProvider itisHhp;
	private Properties rankNameMapping = new Properties();
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.util.AbstractConfigurableAnalyzer#initAnalyzer()
	 */
	public void initAnalyzer() {
		this.itisHhp = new ItisHigherHierarchyProvider(this.dataProvider);
		String[] parameterNames = this.getParameterNames();
		for (int p = 0; p < parameterNames.length; p++)
			if (parameterNames[p].startsWith("rank-")) {
				String providerRankName = parameterNames[p].substring("rank-".length());
				String rankName = this.getParameter(parameterNames[p]);
				this.rankNameMapping.setProperty(providerRankName, rankName);
			}
	}
	
	/* (non-Javadoc)
	 * @see de.uka.ipd.idaho.gamta.util.Analyzer#process(de.uka.ipd.idaho.gamta.MutableAnnotation, java.util.Properties)
	 */
	public void process(MutableAnnotation data, Properties parameters) {
		HashSet downloadedThisDocument = new HashSet();
		Annotation[] taxonNames = data.getAnnotations(TAXONOMIC_NAME_ANNOTATION_TYPE);
		for (int t = 0; t < taxonNames.length; t++) {
			String genus = ((String) taxonNames[t].getAttribute(GENUS_ATTRIBUTE));
			if (genus == null)
				continue;
			
			Properties hierarchy = this.itisHhp.getHierarchy(genus, downloadedThisDocument.add(genus));
			if (hierarchy == null)
				continue;
			
			for (Iterator rit = hierarchy.keySet().iterator(); rit.hasNext();) {
				String providerRank = ((String) rit.next());
				String rank = this.rankNameMapping.getProperty(providerRank);
				if (rank == null)
					continue;
				
				String epithet = hierarchy.getProperty(providerRank);
				taxonNames[t].setAttribute(rank, epithet);
			}
		}
	}
}
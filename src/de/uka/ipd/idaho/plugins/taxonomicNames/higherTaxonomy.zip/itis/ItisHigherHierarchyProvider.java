/*
 * Copyright (c) 2006-2008, IPD Boehm, Universitaet Karlsruhe (TH)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package de.uka.ipd.idaho.plugins.taxonomicNames.itis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import de.uka.ipd.idaho.gamta.util.AnalyzerDataProvider;
import de.uka.ipd.idaho.gamta.util.AnalyzerDataProviderFileBased;
import de.uka.ipd.idaho.htmlXmlUtil.Parser;
import de.uka.ipd.idaho.htmlXmlUtil.TokenReceiver;
import de.uka.ipd.idaho.htmlXmlUtil.TreeNode;
import de.uka.ipd.idaho.htmlXmlUtil.TreeNodeAttributeSet;
import de.uka.ipd.idaho.htmlXmlUtil.accessories.TreeTools;
import de.uka.ipd.idaho.htmlXmlUtil.grammars.Grammar;
import de.uka.ipd.idaho.htmlXmlUtil.grammars.Html;
import de.uka.ipd.idaho.plugins.taxonomicNames.TaxonomicNameConstants;

/**
 * @author sautter
 */
public class ItisHigherHierarchyProvider implements TaxonomicNameConstants {
	
	private static Properties rankNameNormalizer = new Properties();
	static {
		rankNameNormalizer.setProperty("Kingdom", KINGDOM_ATTRIBUTE);
		rankNameNormalizer.setProperty("Phylum", PHYLUM_ATTRIBUTE);
		rankNameNormalizer.setProperty("Division", PHYLUM_ATTRIBUTE);
		rankNameNormalizer.setProperty("Class", CLASS_ATTRIBUTE);
		rankNameNormalizer.setProperty("Order", ORDER_ATTRIBUTE);
		rankNameNormalizer.setProperty("Family", FAMILY_ATTRIBUTE);
		rankNameNormalizer.setProperty("Tribe", TRIBE_ATTRIBUTE);
	}
	
	private AnalyzerDataProvider dataProvider;
	
	/**
	 * Constructor
	 * @param dataProvider the data provider to use for local caching and for
	 *            obtaining URLs for online lookups
	 */
	public ItisHigherHierarchyProvider(AnalyzerDataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}
	
	private HashMap cache = new HashMap();
	
	/**
	 * Obtain the higher taxonomic ranks for a given genus from ITIS. If ITIS
	 * does not provide the higher ranks for the specified genus, or if the ITIS
	 * server is unreachable and the higher ranks for the specified genus are
	 * not cached, this method returns null.
	 * @param genus the genus to get the higher ranks for
	 * @param allowWebAccess allow downloading data from ITIS in case of a file
	 *            cache miss?
	 * @return a Properties object containing the higher taxonomic ranks for the
	 *         argument genus
	 */
	public Properties getHierarchy(String genus, boolean allowWebAccess) {
		Properties hierarchy = ((Properties) this.cache.get(genus));
		if (hierarchy != null) {
			System.out.println("ITIS: Memory cache hit for genus '" + genus + "'");
			return hierarchy;
		}
		
		String cacheDataName = ("cache/" + genus + ".txt");
		
		if (this.dataProvider.isDataAvailable(cacheDataName)) try {
			BufferedReader cacheReader = new BufferedReader(new InputStreamReader(this.dataProvider.getInputStream(cacheDataName), "UTF-8"));
			String line;
			while ((line = cacheReader.readLine()) != null) {
				int split = line.indexOf('=');
				if (split == -1)
					continue;
				String rank = line.substring(0, split);
				String epithet = line.substring(split + 1);
				if (hierarchy == null)
					hierarchy = new Properties();
				hierarchy.setProperty(rankNameNormalizer.getProperty(rank, rank), epithet);
			}
			System.out.println("ITIS: Disc cache hit for genus '" + genus + "'");
		}
		catch (IOException ioe) {
			System.out.println("ITIS: Error loading cached data for genus '" + genus + "': " + ioe.getMessage());
			ioe.printStackTrace(System.out);
			hierarchy = null;
		}
		
		if ((hierarchy != null) && !hierarchy.isEmpty()) {
			this.cache.put(genus, hierarchy);
			return hierarchy;
		}
		
		if (allowWebAccess) try {
			hierarchy = loadHierarchy(genus);
			if ((hierarchy != null) && !hierarchy.isEmpty())
				System.out.println("ITIS: Hierarchy loaded for genus '" + genus + "'");
		}
		catch (IOException ioe) {
			System.out.println("ITIS: Error loading data for genus '" + genus + "': " + ioe.getMessage());
			ioe.printStackTrace(System.out);
			hierarchy = null;
		}
		catch (Exception e) {
			System.out.println("ITIS: Error loading data for genus '" + genus + "': " + e.getMessage());
			e.printStackTrace(System.out);
			hierarchy = null;
		}
		
		if ((hierarchy != null) && !hierarchy.isEmpty()) {
			if (this.dataProvider.isDataEditable()) try {
				BufferedWriter cacheWriter = new BufferedWriter(new OutputStreamWriter(this.dataProvider.getOutputStream(cacheDataName), "UTF-8"));
				for (Iterator rit = hierarchy.keySet().iterator(); rit.hasNext();) {
					String rank = ((String) rit.next());
					String epithet = hierarchy.getProperty(rank);
					cacheWriter.write(rank + "=" + epithet);
					cacheWriter.newLine();
				}
				cacheWriter.flush();
				cacheWriter.close();
			}
			catch (IOException ioe) {
				System.out.println("ITIS: Error caching data for genus '" + genus + "': " + ioe.getMessage());
				ioe.printStackTrace(System.out);
			}
			this.cache.put(genus, hierarchy);
		}
		
		return hierarchy;
	}
	
	private Properties loadHierarchy(final String genus) throws IOException {
		if (genus == null)
			return null;
		
		URL listUrl = this.dataProvider.getURL(baseUrl + queryBase + genus);
		final InputStream listIn = listUrl.openStream();
		final String[] dataLink = {null};
		InputStream filterListIn = new InputStream() {
			public int read() throws IOException {
				if (dataLink[0] == null)
					return listIn.read();
				else return -1;
			}
		};
		parser.stream(filterListIn, new TokenReceiver() {
			String lastLink = null;
			public void close() throws IOException {}
			public void storeToken(String token, int treeDepth) throws IOException {
				if (grammar.isTag(token)) {
					if ("a".equals(grammar.getType(token)) && !grammar.isEndTag(token)) {
						TreeNodeAttributeSet tokenAttributes = TreeNodeAttributeSet.getTagAttributes(token, grammar);
						this.lastLink = tokenAttributes.getAttribute("href");
					}
				}
				else if (genus.equals(token.trim()))
					dataLink[0] = this.lastLink;
			}
		});
		listIn.close();
		
		if (dataLink[0] == null) {
			System.out.println("ITIS: Hierarchy for '" + genus + "' not found.");
			return null;
		}
		
		//next?v_tsn=154211&taxa=&p_king=every&p_string=containing&p_ifx=cbif&p_lang=
		String itisGenusNumber = dataLink[0];
		try {
			itisGenusNumber = itisGenusNumber.substring(itisGenusNumber.indexOf('=') + 1);
			itisGenusNumber = itisGenusNumber.substring(0, itisGenusNumber.indexOf('&'));
		}
		catch (Exception e) {
			System.out.println("ITIS: Error parsing number for genus '" + genus + "' from " + dataLink[0] + ": " + e.getMessage());
			e.printStackTrace(System.out);
			return null;
		}
		
		URL dataUrl = this.dataProvider.getURL(baseUrl + dataBase + itisGenusNumber);
		TreeNode dataRoot = parser.parse(dataUrl.openStream());
		TreeNode[] hierarchyNodes = TreeTools.getAllNodesOfType(dataRoot, "parent");
		Properties hierarchy = new Properties();
		for (int h = 0; h < hierarchyNodes.length; h++) {
			TreeNode rankNode = hierarchyNodes[h].getChildNode("rank", 0);
			TreeNode epithetNode = hierarchyNodes[h].getChildNode("concatenatedname", 0);
			if ((rankNode == null) || (epithetNode == null))
				continue;
			String rank = rankNode.getChildNode(TreeNode.DATA_NODE_TYPE, 0).getNodeValue();
			String nRank = rankNameNormalizer.getProperty(rank);
			if (nRank == null)
				continue;
			String epithet = epithetNode.getChildNode(TreeNode.DATA_NODE_TYPE, 0).getNodeValue();
			hierarchy.setProperty(nRank, epithet);
		}
		return hierarchy;
	}
	
	private static String baseUrl = "http://www.cbif.gc.ca/pls/itisca/";
	private static String queryBase = "taxastep?king=every&p_action=containing&p_format=&p_ifx=cbif&p_lang=&taxa=";
	private static String dataBase = "taxa_xml.upwards?p_type=y&p_lang=&p_tsn=";
	
	private static final Grammar grammar = new Html();
	private static final Parser parser = new Parser(grammar);
	
	// !!! TEST ONLY !!!
	public static void main(String[] args) throws Exception {
		System.getProperties().put("proxySet", "true");
		System.getProperties().put("proxyHost", "proxy.rz.uni-karlsruhe.de");
		System.getProperties().put("proxyPort", "3128");
		
		ItisHigherHierarchyProvider itisHhp = new ItisHigherHierarchyProvider(new AnalyzerDataProviderFileBased(new File("E:/GoldenGATEv3/Plugins/AnalyzerData/ItisHierarchyData/")));
		
		String testGenus = "Chromis";
		Properties hierarchy = itisHhp.getHierarchy(testGenus, true);
		for (Iterator rit = hierarchy.keySet().iterator(); rit.hasNext();) {
			String rank = ((String) rit.next());
			System.out.println(rank + ": " + hierarchy.getProperty(rank));
		}
		
//		MutableAnnotation doc = SgmlDocumentReader.readDocument(new InputStreamReader(new FileInputStream("E:/Projektdaten/TaxonxTest/21330.complete.xml"), "UTF-8"));
//		ihi.process(doc, new Properties());
//		Annotation[] taxonNames = doc.getAnnotations(TAXONOMIC_NAME_ANNOTATION_TYPE);
//		for (int t = 0; t < taxonNames.length; t++)
//			System.out.println(taxonNames[t].toXML());
	}
}
/*
 * Copyright (c) 2006-, IPD Boehm, Universitaet Karlsruhe (TH) / KIT, by Guido Sautter
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the Universit�t Karlsruhe (TH) / KIT nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY UNIVERSIT�T KARLSRUHE (TH) / KIT AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package de.uka.ipd.idaho.plugins.taxonomicNames.col;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;

import de.uka.ipd.idaho.gamta.Annotation;
import de.uka.ipd.idaho.gamta.MutableAnnotation;
import de.uka.ipd.idaho.gamta.util.AnalyzerDataProvider;
import de.uka.ipd.idaho.gamta.util.AnalyzerDataProviderFileBased;
import de.uka.ipd.idaho.gamta.util.SgmlDocumentReader;
import de.uka.ipd.idaho.plugins.taxonomicNames.TaxonomicNameConstants;

/**
 * @author sautter
 */
public class ColHigherHierarchyProvider implements TaxonomicNameConstants {
	
	private static Properties rankNameNormalizer = new Properties();
	static {
		rankNameNormalizer.setProperty("Kingdom", KINGDOM_ATTRIBUTE);
		rankNameNormalizer.setProperty("Phylum", PHYLUM_ATTRIBUTE);
		rankNameNormalizer.setProperty("Division", PHYLUM_ATTRIBUTE);
		rankNameNormalizer.setProperty("Class", CLASS_ATTRIBUTE);
		rankNameNormalizer.setProperty("Order", ORDER_ATTRIBUTE);
		rankNameNormalizer.setProperty("Family", FAMILY_ATTRIBUTE);
		rankNameNormalizer.setProperty("Tribe", TRIBE_ATTRIBUTE);
	}
	
	private AnalyzerDataProvider dataProvider;
	
	/**
	 * Constructor
	 * @param dataProvider the data provider to use for local caching and for
	 *            obtaining URLs for online lookups
	 */
	public ColHigherHierarchyProvider(AnalyzerDataProvider dataProvider) {
		this.dataProvider = dataProvider;
	}
	
	private HashMap cache = new HashMap();
	
	/**
	 * Obtain the higher taxonomic ranks for a given genus from Catalog of Life.
	 * If Catalog of Life does not provide the higher ranks for the specified
	 * genus, or if the Catalog of Life server is unreachable and the higher
	 * ranks for the specified genus are not cached, this method returns null.
	 * Further, if the genus is a homonym and the higher rank epithets cannot
	 * be determined unambiguously, the returned Properties object contains all
	 * available hierarchies, with the keys prefixed with numbers (e.g.
	 * <code>0.kingdom</code> for the kingdom of the first hierarchy found). In
	 * such cases, it is up to client code to determine which hierarchy is the
	 * correct one. 
	 * @param genus the genus to get the higher ranks for
	 * @param allowWebAccess allow downloading data from IPNI in case of a file
	 *            cache miss?
	 * @return a Properties object containing the higher taxonomic ranks for the
	 *         argument genus
	 */
	public Properties getHierarchy(String genus, boolean allowWebAccess) {
		Properties hierarchy = ((Properties) this.cache.get(genus));
		if (hierarchy != null) {
			System.out.println("CoL: Memory cache hit for genus '" + genus + "'");
			return hierarchy;
		}
		
		String cacheDataName = ("cache/" + genus + ".txt");
		
		if (this.dataProvider.isDataAvailable(cacheDataName)) try {
			BufferedReader cacheReader = new BufferedReader(new InputStreamReader(this.dataProvider.getInputStream(cacheDataName), "UTF-8"));
			String line;
			while ((line = cacheReader.readLine()) != null) {
				int split = line.indexOf('=');
				if (split == -1)
					continue;
				String rank = line.substring(0, split);
				String epithet = line.substring(split + 1);
				if (hierarchy == null)
					hierarchy = new Properties();
				hierarchy.setProperty(rank, epithet);
			}
			System.out.println("CoL: Disc cache hit for genus '" + genus + "'");
		}
		catch (IOException ioe) {
			System.out.println("CoL: Error loading cached data for genus '" + genus + "': " + ioe.getMessage());
			ioe.printStackTrace(System.out);
			hierarchy = null;
		}
		
		if ((hierarchy != null) && !hierarchy.isEmpty()) {
			this.cache.put(genus, hierarchy);
			return hierarchy;
		}
		
		if (allowWebAccess) try {
			hierarchy = loadHierarchy(genus);
			if ((hierarchy != null) && !hierarchy.isEmpty())
				System.out.println("CoL: Hierarchy loaded for genus '" + genus + "'");
		}
		catch (IOException ioe) {
			System.out.println("CoL: Error loading data for genus '" + genus + "': " + ioe.getMessage());
			ioe.printStackTrace(System.out);
			hierarchy = null;
		}
		catch (Exception e) {
			System.out.println("CoL: Error loading data for genus '" + genus + "': " + e.getMessage());
			e.printStackTrace(System.out);
			hierarchy = null;
		}
		
		if ((hierarchy != null) && !hierarchy.isEmpty()) {
			if (this.dataProvider.isDataEditable()) try {
				BufferedWriter cacheWriter = new BufferedWriter(new OutputStreamWriter(this.dataProvider.getOutputStream(cacheDataName), "UTF-8"));
				for (Iterator rit = hierarchy.keySet().iterator(); rit.hasNext();) {
					String rank = ((String) rit.next());
					String epithet = hierarchy.getProperty(rank);
					cacheWriter.write(rank + "=" + epithet);
					cacheWriter.newLine();
				}
				cacheWriter.flush();
				cacheWriter.close();
			}
			catch (IOException ioe) {
				System.out.println("CoL: Error caching data for genus '" + genus + "': " + ioe.getMessage());
				ioe.printStackTrace(System.out);
			}
			this.cache.put(genus, hierarchy);
		}
		
		return hierarchy;
	}
	
	private Properties loadHierarchy(final String genus) throws IOException {
		if (genus == null)
			return null;
		
		Reader dataIn = new BufferedReader(new InputStreamReader(this.dataProvider.getURL(baseUrl + genus).openStream(), "UTF-8"));
		MutableAnnotation data = SgmlDocumentReader.readDocument(dataIn);
		dataIn.close();
		
		Properties hierarchy = new Properties();
		MutableAnnotation[] results = data.getMutableAnnotations("result");
		for (int r = 0; r < results.length; r++) {
			MutableAnnotation[] classification = results[r].getMutableAnnotations("classification");
			if (classification.length == 0)
				continue;
			MutableAnnotation[] taxa = classification[0].getMutableAnnotations("taxon");
			for (int t = 0; t < taxa.length; t++) {
				Annotation[] rank = taxa[t].getAnnotations("rank");
				if (rank.length == 0)
					continue;
				String nRank = rankNameNormalizer.getProperty(rank[0].firstValue());
				if (nRank == null)
					continue;
				Annotation[] name = taxa[t].getAnnotations("name");
				if (name.length == 0)
					continue;
				hierarchy.setProperty((((results.length == 1) ? "" : (r + ".")) + nRank), name[0].firstValue());
			}
			MutableAnnotation[] speciesList = results[r].getMutableAnnotations("child_taxa");
			if (speciesList.length == 0)
				continue;
			MutableAnnotation[] species = speciesList[0].getMutableAnnotations("taxon");
			StringBuffer speciesString = new StringBuffer(";");
			for (int s = 0; s < species.length; s++) {
				Annotation[] rank = species[s].getAnnotations("rank");
				if (rank.length == 0)
					continue;
				if (!SPECIES_ATTRIBUTE.equalsIgnoreCase(rank[0].firstValue()))
					continue;
				Annotation[] name = species[s].getAnnotations("name");
				if (name.length == 0)
					continue;
				speciesString.append(name[0].lastValue() + ";");
			}
			if (speciesString.length() > 1)
				hierarchy.setProperty((((results.length == 1) ? "" : (r + ".")) + SPECIES_ATTRIBUTE), speciesString.toString());
		}
		
		return hierarchy;
	}
	
	private static String baseUrl = "http://www.catalogueoflife.org/col/webservice?response=full&name=";
	
	// !!! TEST ONLY !!!
	public static void main(String[] args) throws Exception {
		ColHigherHierarchyProvider colHhp = new ColHigherHierarchyProvider(new AnalyzerDataProviderFileBased(new File("E:/GoldenGATEv3/Plugins/AnalyzerData/IpniHierarchyData/")) {
			public boolean isDataEditable(String dataName) {
				return false;
			}
			public boolean isDataEditable() {
				return false;
			}
		});
		
		String testGenus = "Braunsia";//"Chenopodium";
		Properties hierarchy = colHhp.getHierarchy(testGenus, true);
		for (Iterator rit = hierarchy.keySet().iterator(); rit.hasNext();) {
			String rank = ((String) rit.next());
			if (rank.indexOf('.') != -1)
				break;
			System.out.println(rank + ": " + hierarchy.getProperty(rank));
			if (!rit.hasNext())
				return;
		}
		for (int r = 0;; r++) {
			String prefix = (r + ".");
			boolean prefixEmpty = true;
			for (Iterator rit = hierarchy.keySet().iterator(); rit.hasNext();) {
				String rank = ((String) rit.next());
				if (!rank.startsWith(prefix))
					continue;
				prefixEmpty = false;
				System.out.println(rank.substring(prefix.length()) + ": " + hierarchy.getProperty(rank));
			}
			if (prefixEmpty)
				break;
		}
		
//		MutableAnnotation doc = SgmlDocumentReader.readDocument(new InputStreamReader(new FileInputStream("E:/Projektdaten/TaxonxTest/21330.complete.xml"), "UTF-8"));
//		ihi.process(doc, new Properties());
//		Annotation[] taxonNames = doc.getAnnotations(TAXONOMIC_NAME_ANNOTATION_TYPE);
//		for (int t = 0; t < taxonNames.length; t++)
//			System.out.println(taxonNames[t].toXML());
	}
}